[jgitver-maven-plugin](https://github.com/jgitver/jgitver-maven-plugin) is written and maintained by [Matthieu Brouillard](http://oss.brouillard.fr) [![Email](src/doc/images/black_email_16.png?raw=true "Email")](mailto://matthieu@brouillard.fr) [![Twitt](https://img.shields.io/twitter/url/http/alightinthefog.svg?style=social)](https://twitter.com/alightinthefog)[![Github follow](https://img.shields.io/github/followers/McFoggy.svg?style=social&label=Follow)](https://github.com/McFoggy)

## Contributors
All the following people have contributed to the project.

> Special thanks to Yuriy for his contribution that moved the project from a single plugin to a maven core plugin.

- [Matthieu Brouillard](http://oss.brouillard.fr) [![Email](src/doc/images/black_email_16.png?raw=true "Email")](mailto://matthieu@brouillard.fr) [![Twitt](https://img.shields.io/twitter/url/http/alightinthefog.svg?style=social)](https://twitter.com/alightinthefog)[![Github follow](https://img.shields.io/github/followers/McFoggy.svg?style=social&label=Follow)](https://github.com/McFoggy)
- [Yuriy Zaplavnov](https://github.com/xeagle2) [![Github follow](https://img.shields.io/github/followers/xeagle2.svg?style=social&label=Follow)](https://github.com/xeagle2)
- [Johannes Schneider](https://github.com/jschneider) [![Github follow](https://img.shields.io/github/followers/jschneider.svg?style=social&label=Follow)](https://github.com/jschneider)
- [Jeremy Heiner](https://github.com/jeremy-im) [![Github follow](https://img.shields.io/github/followers/jeremy-im.svg?style=social&label=Follow)](https://github.com/jeremy-im)
